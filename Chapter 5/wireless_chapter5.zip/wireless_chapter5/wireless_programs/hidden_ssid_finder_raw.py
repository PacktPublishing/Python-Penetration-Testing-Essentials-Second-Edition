import socket 
import sys

sniff = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, 3)

mac_ap = raw_input("Enter the MAC ")
if ":"in mac_ap:
	mac_ap = mac_ap.replace(":","")

sniff.bind(("mon0", 0x0003))
processed_client  =[]
filter_dict = {64:'Probe request', 80:'Probe response',32:'Reassociation request',16:'Association response', 0:'Association request' }
filter_type = filter_dict.keys()
probe_request_length = 4+6+6+6+2
while True :
	try:
		fm1 = sniff.recvfrom(6000)
		fm= fm1[0]
		radio_tap_lenght = ord(fm[2])
		if ord(fm[radio_tap_lenght]) in filter_type:
			dest =fm[radio_tap_lenght+4:radio_tap_lenght+4+6].encode('hex')
			source = fm[radio_tap_lenght+4+6 :radio_tap_lenght+4+6+6].encode('hex')
			bssid = fm[radio_tap_lenght+4+6+6 :radio_tap_lenght+4+6+6+6].encode('hex')
			
			if mac_ap == source and dest not in processed_client :
				processed_client.append(dest)
				print processed_client
			if processed_client:
				if ord(fm[radio_tap_lenght]) == 64:
					if source in processed_client:
						ssid_bit = probe_request_length+radio_tap_lenght+1
						lenght_of_ssid=  ord(fm[ssid_bit])
						if lenght_of_ssid:
							print "SSID is ", fm[ssid_bit+1:ssid_bit+1+lenght_of_ssid]

	except KeyboardInterrupt:
		sniff.close()
		print "Bye"
		sys.exit()

	except Exception as e :
		print e



