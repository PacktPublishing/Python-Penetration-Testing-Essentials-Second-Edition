
from scapy.all import *
interface ='mon0'
probe_req = []

BSSID = raw_input("Enter the MAC of AP ")
def probesniff(fm):
	if fm.haslayer(Dot11ProbeReq):
		
		if BSSID == fm.addr2 :
			print fm.info
			
sniff(iface= interface,prn=probesniff)
