import os
import re
import time
import socket
import getpass

host = "192.168.0.128"
port = 54321
while True:
	try:
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		name =socket.gethostname()
		user = getpass.getuser()
		
		response = os.popen('tasklist')
		for line in response.readlines():
			str1 = "Torrent Identified on host "+str(name)+" User "+str(user)
			if re.search("torrent", line.lower()):
				s.sendto(str1,(host,port))
				s.sendto(str1,(host,port))
				s.sendto(str1,(host,port))
				#s.send("")
				break
		
		s.close()
		time.sleep(30)
	except :
		pass