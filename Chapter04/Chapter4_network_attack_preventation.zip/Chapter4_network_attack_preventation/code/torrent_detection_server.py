import socket
import logging
import sys
print "Welcome, torrent dection program started"
print "Use only Ctrl+c to stop"
logger = logging.getLogger("torrent_logger")
logger.setLevel(logging.INFO)
fh = logging.FileHandler("torrent_dection.log")
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
fh.setFormatter(formatter)
logger.addHandler(fh)
logger.info("Torrent detection program started")

prcess_client = []

host = "192.168.0.128"
port = 54321
s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
s.bind((host,port))
while True:
	try:
		
		data, addr = s.recvfrom(1024)
		print "\a\a\a\a\a\a\a"
		if addr[0] not in prcess_client :
			print data, addr[0]
			line = str(data)+" *** "+addr[0]
			logger.info(line)
			line =  "\n****************************\n"
			logger.info(line)
		prcess_client.append(addr[0])
	except KeyboardInterrupt:
		s.close()
		sys.exit()

	except:
		pass


	
