import socket 
host = "192.168.0.100" #Server address
port = 44444  #Port of Server
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((host,port)) #bind server 
s.listen(2) 
while True:
	conn, addr = s.accept()  
	print addr, "Now Connected"
	conn.send("Thank you for connecting")
	print conn.recv(1024)
	conn.close()
